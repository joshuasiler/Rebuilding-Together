-- MySQL dump 10.13  Distrib 5.5.8, for osx10.6 (i386)
--
-- Host: localhost    Database: rebuilding
-- ------------------------------------------------------
-- Server version	5.5.8

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `images`
--

DROP TABLE IF EXISTS `images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image_mime_type` varchar(255) DEFAULT NULL,
  `image_name` varchar(255) DEFAULT NULL,
  `image_size` int(11) DEFAULT NULL,
  `image_width` int(11) DEFAULT NULL,
  `image_height` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `image_uid` varchar(255) DEFAULT NULL,
  `image_ext` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `images`
--

LOCK TABLES `images` WRITE;
/*!40000 ALTER TABLE `images` DISABLE KEYS */;
/*!40000 ALTER TABLE `images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inquiries`
--

DROP TABLE IF EXISTS `inquiries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inquiries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `message` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `spam` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `index_inquiries_on_id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inquiries`
--

LOCK TABLES `inquiries` WRITE;
/*!40000 ALTER TABLE `inquiries` DISABLE KEYS */;
/*!40000 ALTER TABLE `inquiries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inquiry_settings`
--

DROP TABLE IF EXISTS `inquiry_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inquiry_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `value` text,
  `destroyable` tinyint(1) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inquiry_settings`
--

LOCK TABLES `inquiry_settings` WRITE;
/*!40000 ALTER TABLE `inquiry_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `inquiry_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `page_part_translations`
--

DROP TABLE IF EXISTS `page_part_translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `page_part_translations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_part_id` int(11) DEFAULT NULL,
  `locale` varchar(255) DEFAULT NULL,
  `body` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_page_part_translations_on_page_part_id` (`page_part_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `page_part_translations`
--

LOCK TABLES `page_part_translations` WRITE;
/*!40000 ALTER TABLE `page_part_translations` DISABLE KEYS */;
INSERT INTO `page_part_translations` VALUES (1,1,'en',' Rebuilding Together * Portland is a non-profit organization supported entirely by contributions of time, labor, materials, and money.\r\n		    We are dedicated to repairing the homes of those who, due to financial hardship, age, and/or disability cannot do the work themselves.\r\n		    Skilled and unskilled volunteers, along with able-bodied members of the recipients\' family and friends, complete repairs  at no cost to the homeowner.\r\n		    <br /><br />\r\n		    <strong>Free home repairs</strong> are available for low-income homeowners. <a href=\"/homeowners\">Learn more</a>\r\n		    <br /><br />\r\n		    We will be celebrating our 20th year on April 24, 2010.  Our goal is to repair and rehabilitate over 50 homes and non-profit community facilities.\r\n		    <br /><br />\r\n		    <a href=\"/contact;\">Sign up today</a> and join our 1500 strong volunteer workforce on <strong>Rebuilding Day 2010</strong>!\r\n		    <br /><br />\r\n		    \r\n		    <img src=\"/images/photos/_DSC0393.JPG\" />\r\n		    <img src=\"/images/photos/128group.JPG\" />\r\n		    <br /><br />\r\n		    A few of our sponsors:<br /><br />\r\n		    <img src=\"/images/logo-sample.gif\" alt=\"Sponsor logos\" style=\"margin-left:150px;\" />\r\n		    <img alt=\"Cricket Wireless\" src=\"/images/cricketwireless.gif\" />\r\n<h2>Recent Projects</h2>\r\n<a href=\"http://www.mtscottlearningcenters.org/CultivatingMinds.htm\">Cultivating Minds</a> <small>with\r\n  <a href=\"http://www.handsonportland.org/\">Hands On Portland</a> and <a href=\"http://www.mycricket.com/portland\">Cricket Wireless</a>\r\n</small>','2011-12-24 20:46:03','2011-12-24 21:42:42'),(2,2,'en','<p>This is another block of content over here.</p>','2011-12-24 20:46:03','2011-12-24 20:46:03'),(3,3,'en','<h2>Sorry, there was a problem...</h2><p>The page you requested was not found.</p><p><a href=\'/\'>Return to the home page</a></p>','2011-12-24 20:46:03','2011-12-24 20:46:03'),(4,4,'en','\r\n<p>\r\nRebuilding Together * Portland is a non-profit organization supported entirely by contributions of time, labor, materials, and money.  We are dedicated to repairing the homes of those who, due to financial hardship, age, and/or disability cannot do the work themselves.  Skilled and unskilled volunteers along with able-bodied members of the recipients\' family and friends complete repairs  at\r\n<strong>no cost to the homeowner.</strong>\r\n</p>\r\n<p>\r\nTo be eligible for consideration for 2012 the applicant must:\r\n</p>\r\n<ul>\r\n  <li>Be the owner and occupant of the property\r\n  </li>\r\n<li>Be low income; elderly and/or disabled; families with children; veterans\r\n  </li>\r\n<li>Be unable both financially and physically to complete repairs themselves\r\n  </li>\r\n<li>Live in a property located in the City of Portland\r\n</li>\r\n</ul>\r\n\r\n<p>\r\n<strong>Each year Rebuilding Together Portland, screens approximately 150 low income homeowners</strong> and selects about 50-60 homes for\r\nrepair. In addition 5-8 non-profit organizations benefit on the workday and projects throughout the year. Rebuilding Together\r\nPortland organizes 1,200-1,500 volunteers from all walks of life to unite on the last Saturday in April each year to complete\r\nequivalent to $900,000 worth of improvements to the community on that day. Other individual projects are performed throughout\r\nthe year, but most of the work is done on the big day in April. These efforts are made possible with the help of a 20 member\r\nworking board, financial contributions and the efforts of over 1,300 volunteers.\r\n</p>\r\n<img src=\"/images/photos/0425RTP53.jpg\" />\r\n<p>\r\n<strong>Homeowner safety and security are the first priorities</strong> of Rebuilding Together.\r\nOur skilled and unskilled volunteers do all types of work including painting, plumbing, electrical, carpentry,\r\nroofing, weatherization, yard cleaning, debris removal, and much more!  We do need the homeowners to understand\r\nthat time and weather may prevent these volunteers from accomplishing everything that the applicant would like done\r\nto their home on <strong>our next workday, Saturday, April 28th, 2012.</strong>\r\n</p>\r\n<p>\r\nThis is an annual \"barn-raising\" event designed to repair and rehabilitate the homes of low-income, elderly, and\r\ndisabled homeowners as well as selected community non-profit facilities. After a year of planning and preparation,\r\nthe program culminates in a one day \"blitz\" the last Saturday in April. The program has now expanded to include projects\r\nnot only on this day, but year-round as well.\r\n</p>\r\n\r\n<p>\r\n<strong>Rebuilding Together is a nation-wide organization</strong> that, in partnership with the community, rehabilitates the homes of low-income\r\nhomeowners, particularly families with children and the elderly and disabled so that they can continue to live in warmth, safety\r\nand independence. Rebuilding Together-Portland also assists in the rehabilitation of community centers, schools and non-profits.\r\n</p>\r\n<div>\r\n<em>  \r\nCheck out the Rebuilding Together Twitter feed shown here to learn about activities in other cities.\r\n</em>\r\n<br /><br />\r\n\r\n\r\n</div>\r\n<div style=\"clear:both;\">&#160;</div>\r\n<h2>Contact Information</h2>\r\n<strong>Rebuilding Together * Portland</strong>\r\n<br />\r\n5000 N. Willamette Blvd. Portland, OR 97203-5798<br />\r\nPhone: 503-943-7515<br />\r\nFax: 503-943-7322<br />\r\nMikeMalone@rebuildingtogetherportland.org<br />\r\n\r\n<p>\r\n<a href=\"/r/logos_page\">Official Logos available for download</a>\r\n</p>\r\n','2011-12-24 20:46:03','2011-12-24 21:19:15'),(5,5,'en','','2011-12-24 20:46:03','2011-12-24 20:54:45'),(6,6,'en','\r\n<h2>Board Officers</h2>\r\n<table class=\"boardnames\">\r\n<tbody><tr><td class=\"name\">Paul Luty 	</td>\r\n<td>President 	</td>\r\n<td>	University of Portland - Physical Plant</td>\r\n</tr>\r\n<tr><td class=\"name\">Michael Desimone 	</td>\r\n<td>Vice President 	</td>\r\n<td>Key Bank</td>\r\n</tr>\r\n<tr><td class=\"name\">Brian Vetrone 	</td>\r\n<td>Treasurer 	</td>\r\n<td>	Hampton Affiliates</td>\r\n</tr>\r\n<tr><td class=\"name\">Mike Malone 	</td>\r\n<td>Executive Director 	</td>\r\n<td>	Rebuilding Together*Portland</td>\r\n</tr>\r\n<tr><td class=\"name\">Brian Thompson 	</td>\r\n<td>Legal 	</td>\r\n<td> 	Miller Nash LLP</td>\r\n</tr>\r\n<tr><td class=\"name\">Kate Chavez 	</td>\r\n<td>Secretary</td>\r\n<td><a href=\"http://www.enterprisecommunity.com\">Enterprise Community Investment, Inc.</a>\r\n</td></tr>\r\n</tbody>\r\n</table>\r\n\r\n<h2>Board of Directors</h2>\r\n<table class=\"boardnames\">\r\n<tbody><tr><td class=\"name\">Mark Easley 	</td>\r\n<td>KEMA Consulting</td>\r\n</tr>\r\n<tr><td class=\"name\">Valerie Ebinger</td>\r\n<td><a href=\"http://corsource.net\">CorSource Technology Group, Inc.</a>\r\n</td></tr>\r\n\r\n<tr><td class=\"name\">Mitch Falkenstein</td>\r\n<td><a href=\"http://www.paramountequity.com\">Paramount Equity Mortgage</a>\r\n</td></tr>\r\n<tr><td class=\"name\">Amanda Kilmartin 	</td>\r\n<td>Shorestein Co, LCC</td>\r\n</tr>\r\n\r\n<tr><td class=\"name\">Nic Levesque 	</td>\r\n<td><a href=\"http://www.turnerconstruction.com\">Turner Construction</a>\r\n</td></tr>\r\n<tr><td class=\"name\">Dave Lyons 	</td>\r\n<td><a href=\"http://www.jdldev.com\">JDL Development</a>\r\n</td></tr>\r\n<tr><td class=\"name\">Thomas Moore</td>\r\n<td><a href=\"http://www.turnerconstruction.com\">Turner Construction</a>\r\n</td></tr>\r\n\r\n<tr><td class=\"name\">Pat Olson 	</td>\r\n<td>Standard Supply Company</td>\r\n</tr>\r\n<tr><td class=\"name\">Deacon John Ries 	</td>\r\n<td>St. Mary\'s Cathedral</td>\r\n</tr>\r\n\r\n<tr><td class=\"name\">Joshua Siler</td>\r\n<td><a href=\"http://www.hiringthing.com\">HiringThing, Inc.</a>\r\n</td></tr>\r\n<tr><td class=\"name\">Whitney True 	</td>\r\n<td>Lane PR</td>\r\n</tr>\r\n\r\n<tr><td class=\"name\">Sarah Williams</td>\r\n<td><a href=\"http://www.hollandresidential.com\">Holland Residential</a>\r\n</td></tr>\r\n<tr><td class=\"name\">Brandon Zabrocki 	</td>\r\n<td><a href=\"http://www.usbank.com\">US Bank</a>\r\n</td></tr>\r\n\r\n</tbody>\r\n</table>\r\n','2011-12-24 20:58:11','2011-12-24 21:18:58'),(7,7,'en','','2011-12-24 20:58:11','2011-12-24 20:58:11'),(8,8,'en','\r\n <p>\r\n We rely on social service agencies, town offices, service organizations, churches, community groups, and individuals\r\n to help us identify homeowners in Portland in need of our assistance. <strong>Do you know an elderly person, somebody with a disability,\r\n or a working family who could use our help?</strong>\r\n Please review the information on this site and contact us with a completed Home Referral Form.\r\n </p>\r\n<p>\r\n<strong>All repairs are free for homeowners. </strong>Labor and many supplies are typically donated. Homeowners and family members are asked to welcome the volunteers into their homes and work alongside them to the extent possible. Our work is done with families and neighborhoods, not for them. A homeowner brochure is provided to clarify our process and partnership.\r\n</p>\r\n<img src=\"/images/photos/2.jpg\" />\r\n <p>\r\nEligibility requirements include:\r\n</p>\r\n<ul>\r\n  <li>Applicants must own and live in the property where repair work will be done.\r\n  </li>\r\n<li>Assist low income individuals whom are also elderly or disabled or with children\r\n  </li>\r\n<li>Be unable both financially and physically to effect repairs themselves\r\n  </li>\r\n<li>Applicants must be able to produce their mortgage payment book, deed, or other documents showing ownership, if requested.\r\n  </li>\r\n<li>The property is not subject to any pending foreclosure actions or actions to enforce liens.\r\n  </li>\r\n<li>Persons residing in your home or visiting on the designated workday who are physically able will work alongside the volunteers.\r\n   </li>\r\n<li>Be located on a property in the city of Portland.\r\n</li>\r\n</ul>\r\n<p>\r\nIneligible homes include:\r\n</p>\r\n<ul>\r\n  <li>Rental properties\r\n  </li>\r\n<li>Household income above federal poverty guidelines\r\n</li>\r\n</ul>\r\n<p>\r\nHomeowners are carefully selected through an application process which includes income thresholds and a home inspection.\r\nMembers of our House Selection Committees visit applicant homes to confirm eligibility and assess work that needs to be done.\r\nWhile we complete major renovations — including upgrading electrical systems, and many other home\r\nimprovements — we narrow the scope of the work we undertake to what we believe a team of 10-50 skilled and unskilled\r\nvolunteers can accomplish in a day.\r\n</p>\r\n <p>\r\nThe number of homes we work on is tied directly to the amount of money we can raise during the year.\r\nThe House Selection Committee selects the qualifying homes for each year. On average, we renovate more than 50 homes a year\r\nfrom a list of about 150 homeowners. House Captains, generally skilled workers from sponsor groups select homes they\r\nwill champion and set up a detailed plan of work to be done at the home and is the primary contact for the homeowner\r\nthrough completion of the work.\r\n </p>\r\n <p>\r\nThere are no promises that the work planned will actually be done. Weather, volunteer availability and other factors may affect the actual work completed. The House Captain will decide what work can and cannot be done on the day of work. If your home is chosen for the rehabilitation work, there will be NO charge for our service.\r\n</p>\r\n <p>\r\n  <a href=\"/forms/2011/HomeownerReferralForm.docx\" style=\"font-size:1.4em;\">Click Here to Download an Application</a>\r\n </p>\r\n <h2>Contact Information</h2>\r\n<strong>Rebuilding Together * Portland</strong>\r\n<br />\r\n5000 N. Willamette Blvd. Portland, OR 97203-5798<br />\r\nPhone: 503-943-7515<br />\r\nFax: 503-943-7322<br />\r\n<a href=\"mailto:MikeMalone@rebuildingtogetherportland.org\">MikeMalone@rebuildingtogetherportland.org</a>\r\n<br />\r\n\r\n','2011-12-24 20:59:29','2011-12-24 21:22:35'),(9,9,'en',' \r\n <p>House Captains are our project leaders, and help ensure that each and every project is a success on rebuilding day.\r\n If you are interested in becoming a House Captain, please contact <a href=\"mailto:MikeMalone@RebuildingTogetherPortland.org\">Mike Malone at MikeMalone@RebuildingTogetherPortland.org</a>\r\n</p>\r\n\r\n <p>If you\'ve already signed up, <strong>thank you!</strong> The House Captain\'s role is a crucial element in making our program a success.  It is your skills, hard work and dedication that get our repair and rehabilitation work completed effectively and efficiently.  This role will be challenging and at the same time very rewarding.\r\n </p>\r\n<p>\r\nFor more information, start here: <a href=\"/files/RT2011hcltter.doc\">Letter to House Captains</a> (with 2011 schedule)\r\n</p>\r\n<h2>Resources for House Captains</h2>\r\n<ul>\r\n<li style=\"list-style-image: url(/images/icons/new.png);margin-bottom: 20px;\"><em>Updated for 2011</em>\r\n</li>\r\n\r\n\r\n<li style=\"list-style-image: url(/images/icons/page_white_acrobat.png);\"><a href=\"/files/2011/2011_campus_map.pdf\">\r\n	\r\n		Campus\r\n\r\n		Map\r\n</a>\r\n</li>\r\n\r\n\r\n<li style=\"list-style-image: url(/images/icons/page_word.png);\"><a href=\"/files/2011/2011_guidelines_for_house_liaisons.doc\">\r\n	\r\n		Guidelines\r\n\r\n		For\r\n\r\n		House\r\n\r\n		Liaisons\r\n</a>\r\n</li>\r\n\r\n\r\n<li style=\"list-style-image: url(/images/icons/page_word.png);\"><a href=\"/files/2011/2011_hc_handbook_planning_ahead.doc.doc\">\r\n	\r\n		Hc\r\n\r\n		Handbook\r\n\r\n		Planning\r\n\r\n		Ahead\r\n</a>\r\n</li>\r\n\r\n\r\n<li style=\"list-style-image: url(/images/icons/page_word.png);\"><a href=\"/files/2011/2011_hc_handbook_the_work_day.doc.doc\">\r\n	\r\n		Hc\r\n\r\n		Handbook\r\n\r\n		The\r\n\r\n		Work\r\n\r\n		Day\r\n</a>\r\n</li>\r\n\r\n\r\n<li style=\"list-style-image: url(/images/icons/page_word.png);\"><a href=\"/files/2011/2011_hc_orientation_agenda.doc\">\r\n	\r\n		Hc\r\n\r\n		Orientation\r\n\r\n		Agenda\r\n</a>\r\n</li>\r\n\r\n\r\n<li style=\"list-style-image: url(/images/icons/page_word.png);\"><a href=\"/files/2011/2011_hc_role_&amp;_responsibilities.doc\">\r\n	\r\n		Hc\r\n\r\n		Role\r\n\r\n		&amp;\r\n\r\n		Responsibilities\r\n</a>\r\n</li>\r\n\r\n\r\n<li style=\"list-style-image: url(/images/icons/page_word.png);\"><a href=\"/files/2011/2011_hc_volunteer_list_work_sheet.doc\">\r\n	\r\n		Hc\r\n\r\n		Volunteer\r\n\r\n		List\r\n\r\n		Work\r\n\r\n		Sheet\r\n</a>\r\n</li>\r\n\r\n\r\n<li style=\"list-style-image: url(/images/icons/page_word.png);\"><a href=\"/files/2011/2011_homeowner_agreement.doc\">\r\n	\r\n		Homeowner\r\n\r\n		Agreement\r\n</a>\r\n</li>\r\n\r\n\r\n<li style=\"list-style-image: url(/images/icons/page_word.png);\"><a href=\"/files/2011/2011_homeowner_interview-house_inspection_sign_up.doc\">\r\n	\r\n		Homeowner\r\n\r\n		Interview-house\r\n\r\n		Inspection\r\n\r\n		Sign\r\n\r\n		Up\r\n</a>\r\n</li>\r\n\r\n\r\n<li style=\"list-style-image: url(/images/icons/page_word.png);\"><a href=\"/files/2011/2011_house_captain_evaluation.doc\">\r\n	\r\n		House\r\n\r\n		Captain\r\n\r\n		Evaluation\r\n</a>\r\n</li>\r\n\r\n\r\n<li style=\"list-style-image: url(/images/icons/page_word.png);\"><a href=\"/files/2011/2011_house_captains_reminder_lttr.doc\">\r\n	\r\n		House\r\n\r\n		Captains\r\n\r\n		Reminder\r\n\r\n		Lttr\r\n</a>\r\n</li>\r\n\r\n\r\n<li style=\"list-style-image: url(/images/icons/page_word.png);\"><a href=\"/files/2011/2011_house_caption_flow_chart_for_recruiting_volunteers.doc\">\r\n	\r\n		House\r\n\r\n		Caption\r\n\r\n		Flow\r\n\r\n		Chart\r\n\r\n		For\r\n\r\n		Recruiting\r\n\r\n		Volunteers\r\n</a>\r\n</li>\r\n\r\n\r\n<li style=\"list-style-image: url(/images/icons/page_word.png);\"><a href=\"/files/2011/2011_lead-safe_remodeling_procedures.doc\">\r\n	\r\n		Lead-safe\r\n\r\n		Remodeling\r\n\r\n		Procedures\r\n</a>\r\n</li>\r\n\r\n\r\n<li style=\"list-style-image: url(/images/icons/page_white_acrobat.png);\"><a href=\"/files/2011/2011_lowes_order_form.pdf\">\r\n	\r\n		Lowes\r\n\r\n		Order\r\n\r\n		Form\r\n</a>\r\n</li>\r\n\r\n\r\n<li style=\"list-style-image: url(/images/icons/page_excel.png);\"><a href=\"/files/2011/2011_material_help.xls\">\r\n	\r\n		Material\r\n\r\n		Help\r\n</a>\r\n</li>\r\n\r\n\r\n<li style=\"list-style-image: url(/images/icons/page_word.png);\"><a href=\"/files/2011/2011_med_treatment_authorization_for_minor.doc\">\r\n	\r\n		Med\r\n\r\n		Treatment\r\n\r\n		Authorization\r\n\r\n		For\r\n\r\n		Minor\r\n</a>\r\n</li>\r\n\r\n\r\n<li style=\"list-style-image: url(/images/icons/page_word.png);\"><a href=\"/files/2011/2011_safety_tool_box_talk_guidelines.doc\">\r\n	\r\n		Safety\r\n\r\n		Tool\r\n\r\n		Box\r\n\r\n		Talk\r\n\r\n		Guidelines\r\n</a>\r\n</li>\r\n\r\n\r\n<li style=\"list-style-image: url(/images/icons/page_word.png);\"><a href=\"/files/2011/2011_scope_of_work.doc\">\r\n	\r\n		Scope\r\n\r\n		Of\r\n\r\n		Work\r\n</a>\r\n</li>\r\n\r\n\r\n<li style=\"list-style-image: url(/images/icons/page_word.png);\"><a href=\"/files/2011/2011_updated_volunteer_agreement_and_release.doc\">\r\n	\r\n		Updated\r\n\r\n		Volunteer\r\n\r\n		Agreement\r\n\r\n		And\r\n\r\n		Release\r\n</a>\r\n</li>\r\n\r\n\r\n<li style=\"list-style-image: url(/images/icons/page_word.png);\"><a href=\"/files/2011/2011_volunteer_estimate_form.doc\">\r\n	\r\n		Volunteer\r\n\r\n		Estimate\r\n\r\n		Form\r\n</a>\r\n</li>\r\n\r\n\r\n<li style=\"list-style-image: url(/images/icons/page_word.png);\"><a href=\"/files/2011/2011_volunteer_opportunities_form.doc\">\r\n	\r\n		Volunteer\r\n\r\n		Opportunities\r\n\r\n		Form\r\n</a>\r\n</li>\r\n\r\n\r\n<li style=\"list-style-image: url(/images/icons/page_word.png);\"><a href=\"/files/2011/lowes_material_procedures_2011.doc\">\r\n	\r\n		Lowes\r\n\r\n		Material\r\n\r\n		Procedures\r\n</a>\r\n</li>\r\n\r\n\r\n<li style=\"list-style-image: url(/images/icons/page_word.png);\"><a href=\"/files/2011/xmas_2011_hc_lttr.doc\">\r\n	\r\n		Xmas\r\n\r\n		Hc\r\n\r\n		Lttr\r\n</a>\r\n</li>\r\n\r\n</ul>\r\n\r\n <h2>Contact Information</h2>\r\n<strong>Dave Lyons, Committee Chairman</strong>\r\n<br />\r\nDays - 503-248-2030 and evenings - 503-287-9915<br />\r\nPlease confirm your attendance: <a href=\"dave@jdldev.com\">Dave Lyons - dave@jdldev.com</a> or <a href=\"mailto:MikeMalone@RebuildingTogetherPortland.org\">Mike Malone - MikeMalone@RebuildingTogetherPortland.org</a>\r\n<br /><br />\r\n<strong>Rebuilding Together * Portland</strong>\r\n<br />\r\n5000 N. Willamette Blvd. Portland, OR 97203-5798<br />\r\nPhone: 503-943-7515<br />\r\nFax: 503-943-7322<br />\r\n<a href=\"mailto:MikeMalone@rebuildingtogetherportland.org\">MikeMalone@rebuildingtogetherportland.org</a>\r\n<br />\r\n\r\n\r\n		\r\n','2011-12-24 20:59:55','2011-12-24 21:21:15'),(10,10,'en','\r\n<p>\r\n<strong>Free facility repairs available for Non-Profits.</strong> It\'s Rebuilding Together Portland to the rescue!\r\n</p>\r\n<p>\r\nSince 1990 Rebuilding Together Portland has been realizing ambitious annual goals to repair and rehabilitate both homes and non-profit community facilities. While more than 50 homes are worked on each year, Rebuilding Together Portland also helps five or six non-profits each year with free facility repairs. Rebuilding Together Portland matches coordinates projects year-round, but most of the work is done on the last Saturday in April each year by more than a thousand volunteers on that one day.\r\n</p>\r\n<p>\r\nRebuilding Together is a non-profit organization supported entirely by contributions of time, labor, materials, and money. Our core competencies include identifying worthy homeowners and non-profits in need and matching them with volunteers, supplies and materials. Rebuilding Together Portland coordinates skilled and unskilled volunteers and materials needed to complete the work in a day or two. We are always looking for good projects at non-profit properties where volunteers will enjoy and appreciate their contribution.\r\n</p>\r\n<p>\r\nTo be eligible for consideration, the applicant\'s property must:\r\n</p>\r\n<ul>\r\n    <li>Be the owner and occupant of the property\r\n    </li>\r\n<li>Assist low income individuals whom are also elderly or disabled or with children\r\n    </li>\r\n<li>Be unable both financially and physically to effect repairs themselves\r\n    </li>\r\n<li>Be located on a property in the city of Portland.\r\n</li>\r\n</ul>\r\n<p>\r\nSafety and security are the first priorities of Rebuilding Together. Our skilled and unskilled volunteers do all\r\ntypes of work including painting, plumbing, electrical, carpentry, weatherization, yard cleaning,\r\ndebris removal, and much more!\r\n</p>\r\n<p>\r\nWhen a project is accepted, a scope of work is defined in advance, but the non-profit organization and homeowners\r\nneed to understand these are volunteers and that time and weather may prevent them from\r\naccomplishing everything planned to be completed.\r\n</p>\r\n<p>\r\nTo become eligible for assistance, fill out our Non-profit Referral Form.\r\n</p>\r\n <p>\r\n  <a href=\"/forms/2012/Non-ProfitReferralForm12.doc\" style=\"font-size:1.4em;\">Click Here to Download an Application</a>\r\n </p>\r\n <h2>Contact Information</h2>\r\n<strong>Rebuilding Together * Portland</strong>\r\n<br />\r\n5000 N. Willamette Blvd. Portland, OR 97203-5798<br />\r\nPhone: 503-943-7515<br />\r\nFax: 503-943-7322<br />\r\n<a href=\"mailto:MikeMalone@rebuildingtogetherportland.org\">MikeMalone@rebuildingtogetherportland.org</a>\r\n<br />\r\n\r\n','2011-12-24 21:00:43','2011-12-24 21:22:58'),(11,11,'en','The elements of the \r\n									national logo consist of the artwork (\"the \r\n									symbol\") and the words Rebuilding Together. \r\n									It is a unique mark and may not be altered. \r\n									The logo must not be redrawn and cannot \r\n									include any additional graphic \r\n									embellishments. The position and size \r\n									relationship of the elements should not be \r\n									changed. It should be reproduced from the \r\n									artwork provided by the national \r\n									organization or from a digital version, \r\n									available on the CD accompanying this manual \r\n									or downloadable from the members-only \r\n									section of www.rebuildingtogether.org in a \r\n									number of formats and versions. The national \r\n									office has trademark protection for the \r\n									Rebuilding Together logo. Always use the ® \r\n									that appears at the base of the \"r\" in \r\n									\"Together.\" Do not use the logo as a part of \r\n									another corporate name.<br />\r\n									By downloading any logos from this site, you \r\n									are agreeing to adhere to these guidelines.\r\n\r\n<h2>Downloads</h2>\r\n<style>\r\n  img\r\n  {\r\n    border: none;\r\n  }\r\n</style>\r\n<table style=\"width: 100%\">\r\n									<tbody><tr>\r\n										<td class=\"style20\">\r\n										<span class=\"style19\">&#160;<a href=\"/logos/RT_2Clogo_horiz.jpg\" class=\"style14\"><img src=\"/images/RT_2Clogo_horiz_small.jpg\" width=\"344\" height=\"100\" class=\"style17\" /></a>\r\n<br />\r\n										<a href=\"/logos/RT_2Clogo_horiz.eps\">\r\n										RT_2Clogo_horiz.eps</a>\r\n<br />\r\n										<a href=\"/logos/RT_2Clogo_horiz.jpg\">\r\n										RT_2Clogo_horiz.jpg</a>\r\n<br />\r\n										</span>\r\n</td>\r\n										<td class=\"style23\">&#160;<a href=\"/logos/RT_2Clogo_stacked.jpg\"><span class=\"style22\"><img src=\"/images/RT_2Clogo_stacked_small.jpg\" width=\"204\" height=\"100\" class=\"style21\" /></span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n										<a href=\"/logos/RT_2Clogo_stacked.jpg\">\r\n										<span class=\"style22\">\r\n										RT_2Clogo_stacked.jpg</span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n										<a href=\"/logos/RT_2Clogo_stacked.eps\">\r\n										<span class=\"style22\">\r\n										RT_2Clogo_stacked.eps</span>\r\n</a>\r\n</td>\r\n									</tr>\r\n									<tr class=\"style19\">\r\n										<td class=\"style23\">\r\n										<span class=\"style22\">&#160;</span>\r\n<a href=\"/logos/RT_Blacklogo_horiz.jpg\"><span class=\"style22\"><img src=\"/images/RT_Blacklogo_horiz_small.jpg\" width=\"344\" height=\"100\" class=\"style21\" /></span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n										<a href=\"/logos/RT_Blacklogo_horiz.jpg\">\r\n										<span class=\"style22\">\r\n										RT_Blacklogo_horiz.jpg</span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n										<a href=\"/logos/RT_Blacklogo_horiz.eps\">\r\n										<span class=\"style22\">\r\n										RT_Blacklogo_horiz.eps</span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n</td>\r\n										<td class=\"style23\">&#160;<a href=\"/logos/RT_Blacklogo_stacked.jpg\"><span class=\"style22\"><img src=\"/images/RT_Blacklogo_stacked_small.jpg\" width=\"204\" height=\"100\" class=\"style21\" /></span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n										<a href=\"/logos/RT_Blacklogo_stacked.jpg\">\r\n										<span class=\"style22\">\r\n										RT_Blacklogo_stacked.jpg</span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n										<a href=\"/logos/RT_Blacklogo_stacked.eps\">\r\n										<span class=\"style22\">\r\n										RT_Blacklogo_stacked.eps</span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n</td>\r\n									</tr>\r\n									<tr class=\"style19\">\r\n										<td class=\"style23\">\r\n										<span class=\"style22\">&#160;</span>\r\n<a href=\"/logos/RT_GSlogo_horiz.jpg\"><span class=\"style22\"><img src=\"/images/RT_GSlogo_horiz_small.jpg\" width=\"344\" height=\"100\" class=\"style21\" /></span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n										<a href=\"/logos/RT_GSlogo_horiz.jpg\">\r\n										<span class=\"style22\">\r\n										RT_GSlogo_horiz.jpg</span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n										<a href=\"/logos/RT_GSlogo_horiz.eps\">\r\n										<span class=\"style22\">\r\n										RT_GSlogo_horiz.eps</span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n</td>\r\n										<td class=\"style23\">&#160;<a href=\"/logos/RT_GSlogo_stacked.jpg\"><span class=\"style22\"><img src=\"/images/RT_GSlogo_stacked_small.jpg\" width=\"204\" height=\"100\" class=\"style21\" /></span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n										<a href=\"/logos/RT_GSlogo_stacked.jpg\">\r\n										<span class=\"style22\">\r\n										RT_GSlogo_stacked.jpg</span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n										<a href=\"/logos/RT_GSlogo_stacked.eps\">\r\n										<span class=\"style22\">\r\n										RT_GSlogo_stacked.eps</span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n</td>\r\n									</tr>\r\n									<tr class=\"style19\">\r\n										<td class=\"style23\">\r\n										<span class=\"style22\">&#160;</span>\r\n<a href=\"/logos/RT_PMS368logo_horiz.jpg\"><span class=\"style22\"><img src=\"/images/RT_PMS368logo_horiz_small.jpg\" width=\"344\" height=\"100\" class=\"style21\" /></span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n										<a href=\"/logos/RT_PMS368logo_horiz.jpg\">\r\n										<span class=\"style22\">\r\n										RT_PMS368logo_horiz.jpg</span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n										<a href=\"/logos/RT_PMS368logo_horiz.eps\">\r\n										<span class=\"style22\">\r\n										RT_PMS368logo_horiz.eps</span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n</td>\r\n										<td class=\"style23\">&#160;<a href=\"/logos/RT_PMS368logo_stacked.jpg\"><span class=\"style22\"><img src=\"/images/RT_PMS368logo_stacked_small.jpg\" width=\"204\" height=\"100\" class=\"style21\" /></span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n										<a href=\"/logos/RT_PMS368logo_stacked.jpg\">\r\n										<span class=\"style22\">\r\n										RT_PMS368logo_stacked.jpg</span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n										<a href=\"/logos/RT_PMS368logo_stacked.eps\">\r\n										<span class=\"style22\">\r\n										RT_PMS368logo_stacked.eps</span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n</td>\r\n									</tr>\r\n									<tr class=\"style19\">\r\n										<td class=\"style23\">\r\n										<span class=\"style22\">&#160;</span>\r\n<a href=\"/logos/RT_KOlogo_horiz.jpg\"><span class=\"style22\"><img src=\"/images/RT_KOlogo_horiz_small.jpg\" width=\"291\" height=\"100\" class=\"style21\" /></span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n										<a href=\"/logos/RT_KOlogo_horiz.jpg\">\r\n										<span class=\"style22\">\r\n										RT_KOlogo_horiz.jpg</span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n										<a href=\"/logos/RT_KOlogo_horiz.eps\">\r\n										<span class=\"style22\">\r\n										RT_KOlogo_horiz.eps</span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n</td>\r\n										<td class=\"style23\">&#160;<a href=\"/logos/RT_KOlogo_stacked.jpg\"><span class=\"style22\"><img src=\"/images/RT_KOlogo_stacked_small.jpg\" width=\"192\" height=\"100\" class=\"style21\" /></span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n										<a href=\"/logos/RT_KOlogo_stacked.jpg\">\r\n										<span class=\"style22\">\r\n										RT_KOlogo_stacked.jpg</span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n										<a href=\"/logos/RT_KOlogo_stacked.eps\">\r\n										<span class=\"style22\">\r\n										RT_KOlogo_stacked.eps</span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n</td>\r\n									</tr>\r\n									<tr class=\"style19\">\r\n										<td class=\"style23\">\r\n										<span class=\"style22\">&#160;</span>\r\n<a href=\"/logos/RT_KOlogo_horizWHT.jpg\"><span class=\"style22\"><img src=\"/images/RT_KOlogo_horizWHT_small.jpg\" width=\"282\" height=\"100\" class=\"style21\" /></span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n										<a href=\"/logos/RT_KOlogo_horizWHT.jpg\">\r\n										<span class=\"style22\">\r\n										RT_KOlogo_horizWHT.jpg</span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n										<a href=\"/logos/RT_KOlogo_horizWHT.eps\">\r\n										<span class=\"style22\">\r\n										RT_KOlogo_horizWHT.eps</span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n</td>\r\n										<td class=\"style23\">&#160;<a href=\"/logos/RT_KOlogo_stackedWHT.jpg\"><span class=\"style22\"><img src=\"/images/RT_KOlogo_stackedWHT_small.jpg\" width=\"184\" height=\"100\" class=\"style21\" /></span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n										<a href=\"/logos/RT_KOlogo_stackedWHT.jpg\">\r\n										<span class=\"style22\">\r\n										RT_KOlogo_stackedWHT.jpg</span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n										<a href=\"/logos/RT_KOlogo_stackedWHT.eps\">\r\n										<span class=\"style22\">\r\n										RT_KOlogo_stackedWHT.eps</span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n</td>\r\n									</tr>\r\n								</tbody>\r\n</table>','2011-12-24 21:02:35','2011-12-24 21:03:14'),(12,12,'en','<p>\r\n	<strong>You can make a difference.</strong> Experience the great feeling that comes with helping out your community. Our volunteers come to us with all different levels of skills, and every helping hand makes a difference.\r\n	Whether you\'re a skilled tradesman or simply looking to help out any way you can, please fill out the form below to get started. Also, we\'ll need these forms completed before the work day:\r\n<br /><br />\r\n\r\n<a href=\"/files/2011/2011_med_treatment_authorization_for_minor.doc\">Medical Treatment Authorization (for minors)</a>\r\n<br />\r\n<a href=\"/files/2011/2011_updated_volunteer_agreement_and_release.doc\">Volunteer\'s Agreement</a>\r\n</p>\r\n','2011-12-24 21:27:22','2011-12-24 21:31:00'),(13,13,'en','<p><strong>Rebuilding Together * Portland</strong>\r\n<br />\r\n5000 N. Willamette Blvd. Portland, OR 97203-5798<br />\r\nPhone: 503-943-7515<br />\r\nFax: 503-943-7322<br />\r\n<a href=\"mailto:MikeMalone@rebuildingtogetherportland.org\">MikeMalone@rebuildingtogetherportland.org</a>\r\n<br />\r\n</p>\r\n','2011-12-24 21:27:22','2011-12-24 21:33:50'),(14,14,'en','<p>We\'ve received your inquiry and will get back to you with a response shortly.</p><p><a href=\'/\'>Return to the home page</a></p>','2011-12-24 21:27:22','2011-12-24 21:27:22'),(15,15,'en','<p>We respect your privacy. We do not market, rent or sell our email list to any outside parties.</p><p>We need your e-mail address so that we can ensure that the people using our forms are bona fide. It also allows us to send you e-mail newsletters and other communications, if you opt-in. Your postal address is required in order to send you information and pricing, if you request it.</p><p>Please call us at 123 456 7890 if you have any questions or concerns.</p>','2011-12-24 21:27:22','2011-12-24 21:27:22');
/*!40000 ALTER TABLE `page_part_translations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `page_parts`
--

DROP TABLE IF EXISTS `page_parts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `page_parts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_id` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `body` text,
  `position` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_page_parts_on_id` (`id`),
  KEY `index_page_parts_on_page_id` (`page_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `page_parts`
--

LOCK TABLES `page_parts` WRITE;
/*!40000 ALTER TABLE `page_parts` DISABLE KEYS */;
INSERT INTO `page_parts` VALUES (1,1,'Body',' Rebuilding Together * Portland is a non-profit organization supported entirely by contributions of time, labor, materials, and money.\r\n		    We are dedicated to repairing the homes of those who, due to financial hardship, age, and/or disability cannot do the work themselves.\r\n		    Skilled and unskilled volunteers, along with able-bodied members of the recipients\' family and friends, complete repairs  at no cost to the homeowner.\r\n		    <br /><br />\r\n		    <strong>Free home repairs</strong> are available for low-income homeowners. <a href=\"/homeowners\">Learn more</a>\r\n		    <br /><br />\r\n		    We will be celebrating our 20th year on April 24, 2010.  Our goal is to repair and rehabilitate over 50 homes and non-profit community facilities.\r\n		    <br /><br />\r\n		    <a href=\"/contact;\">Sign up today</a> and join our 1500 strong volunteer workforce on <strong>Rebuilding Day 2010</strong>!\r\n		    <br /><br />\r\n		    \r\n		    <img src=\"/images/photos/_DSC0393.JPG\" />\r\n		    <img src=\"/images/photos/128group.JPG\" />\r\n		    <br /><br />\r\n		    A few of our sponsors:<br /><br />\r\n		    <img src=\"/images/logo-sample.gif\" alt=\"Sponsor logos\" style=\"margin-left:150px;\" />\r\n		    <img alt=\"Cricket Wireless\" src=\"/images/cricketwireless.gif\" />\r\n<h2>Recent Projects</h2>\r\n<a href=\"http://www.mtscottlearningcenters.org/CultivatingMinds.htm\">Cultivating Minds</a> <small>with\r\n  <a href=\"http://www.handsonportland.org/\">Hands On Portland</a> and <a href=\"http://www.mycricket.com/portland\">Cricket Wireless</a>\r\n</small>',0,'2011-12-24 20:46:03','2011-12-24 21:42:42'),(3,2,'Body','<h2>Sorry, there was a problem...</h2><p>The page you requested was not found.</p><p><a href=\'/\'>Return to the home page</a></p>',0,'2011-12-24 20:46:03','2011-12-24 20:46:03'),(4,3,'Body','\r\n<p>\r\nRebuilding Together * Portland is a non-profit organization supported entirely by contributions of time, labor, materials, and money.  We are dedicated to repairing the homes of those who, due to financial hardship, age, and/or disability cannot do the work themselves.  Skilled and unskilled volunteers along with able-bodied members of the recipients\' family and friends complete repairs  at\r\n<strong>no cost to the homeowner.</strong>\r\n</p>\r\n<p>\r\nTo be eligible for consideration for 2012 the applicant must:\r\n</p>\r\n<ul>\r\n  <li>Be the owner and occupant of the property\r\n  </li>\r\n<li>Be low income; elderly and/or disabled; families with children; veterans\r\n  </li>\r\n<li>Be unable both financially and physically to complete repairs themselves\r\n  </li>\r\n<li>Live in a property located in the City of Portland\r\n</li>\r\n</ul>\r\n\r\n<p>\r\n<strong>Each year Rebuilding Together Portland, screens approximately 150 low income homeowners</strong> and selects about 50-60 homes for\r\nrepair. In addition 5-8 non-profit organizations benefit on the workday and projects throughout the year. Rebuilding Together\r\nPortland organizes 1,200-1,500 volunteers from all walks of life to unite on the last Saturday in April each year to complete\r\nequivalent to $900,000 worth of improvements to the community on that day. Other individual projects are performed throughout\r\nthe year, but most of the work is done on the big day in April. These efforts are made possible with the help of a 20 member\r\nworking board, financial contributions and the efforts of over 1,300 volunteers.\r\n</p>\r\n<img src=\"/images/photos/0425RTP53.jpg\" />\r\n<p>\r\n<strong>Homeowner safety and security are the first priorities</strong> of Rebuilding Together.\r\nOur skilled and unskilled volunteers do all types of work including painting, plumbing, electrical, carpentry,\r\nroofing, weatherization, yard cleaning, debris removal, and much more!  We do need the homeowners to understand\r\nthat time and weather may prevent these volunteers from accomplishing everything that the applicant would like done\r\nto their home on <strong>our next workday, Saturday, April 28th, 2012.</strong>\r\n</p>\r\n<p>\r\nThis is an annual \"barn-raising\" event designed to repair and rehabilitate the homes of low-income, elderly, and\r\ndisabled homeowners as well as selected community non-profit facilities. After a year of planning and preparation,\r\nthe program culminates in a one day \"blitz\" the last Saturday in April. The program has now expanded to include projects\r\nnot only on this day, but year-round as well.\r\n</p>\r\n\r\n<p>\r\n<strong>Rebuilding Together is a nation-wide organization</strong> that, in partnership with the community, rehabilitates the homes of low-income\r\nhomeowners, particularly families with children and the elderly and disabled so that they can continue to live in warmth, safety\r\nand independence. Rebuilding Together-Portland also assists in the rehabilitation of community centers, schools and non-profits.\r\n</p>\r\n<div>\r\n<em>  \r\nCheck out the Rebuilding Together Twitter feed shown here to learn about activities in other cities.\r\n</em>\r\n<br /><br />\r\n\r\n\r\n</div>\r\n<div style=\"clear:both;\">&#160;</div>\r\n<h2>Contact Information</h2>\r\n<strong>Rebuilding Together * Portland</strong>\r\n<br />\r\n5000 N. Willamette Blvd. Portland, OR 97203-5798<br />\r\nPhone: 503-943-7515<br />\r\nFax: 503-943-7322<br />\r\nMikeMalone@rebuildingtogetherportland.org<br />\r\n\r\n<p>\r\n<a href=\"/r/logos_page\">Official Logos available for download</a>\r\n</p>\r\n',0,'2011-12-24 20:46:03','2011-12-24 21:19:14'),(6,4,'Body','\r\n<h2>Board Officers</h2>\r\n<table class=\"boardnames\">\r\n<tbody><tr><td class=\"name\">Paul Luty 	</td>\r\n<td>President 	</td>\r\n<td>	University of Portland - Physical Plant</td>\r\n</tr>\r\n<tr><td class=\"name\">Michael Desimone 	</td>\r\n<td>Vice President 	</td>\r\n<td>Key Bank</td>\r\n</tr>\r\n<tr><td class=\"name\">Brian Vetrone 	</td>\r\n<td>Treasurer 	</td>\r\n<td>	Hampton Affiliates</td>\r\n</tr>\r\n<tr><td class=\"name\">Mike Malone 	</td>\r\n<td>Executive Director 	</td>\r\n<td>	Rebuilding Together*Portland</td>\r\n</tr>\r\n<tr><td class=\"name\">Brian Thompson 	</td>\r\n<td>Legal 	</td>\r\n<td> 	Miller Nash LLP</td>\r\n</tr>\r\n<tr><td class=\"name\">Kate Chavez 	</td>\r\n<td>Secretary</td>\r\n<td><a href=\"http://www.enterprisecommunity.com\">Enterprise Community Investment, Inc.</a>\r\n</td></tr>\r\n</tbody>\r\n</table>\r\n\r\n<h2>Board of Directors</h2>\r\n<table class=\"boardnames\">\r\n<tbody><tr><td class=\"name\">Mark Easley 	</td>\r\n<td>KEMA Consulting</td>\r\n</tr>\r\n<tr><td class=\"name\">Valerie Ebinger</td>\r\n<td><a href=\"http://corsource.net\">CorSource Technology Group, Inc.</a>\r\n</td></tr>\r\n\r\n<tr><td class=\"name\">Mitch Falkenstein</td>\r\n<td><a href=\"http://www.paramountequity.com\">Paramount Equity Mortgage</a>\r\n</td></tr>\r\n<tr><td class=\"name\">Amanda Kilmartin 	</td>\r\n<td>Shorestein Co, LCC</td>\r\n</tr>\r\n\r\n<tr><td class=\"name\">Nic Levesque 	</td>\r\n<td><a href=\"http://www.turnerconstruction.com\">Turner Construction</a>\r\n</td></tr>\r\n<tr><td class=\"name\">Dave Lyons 	</td>\r\n<td><a href=\"http://www.jdldev.com\">JDL Development</a>\r\n</td></tr>\r\n<tr><td class=\"name\">Thomas Moore</td>\r\n<td><a href=\"http://www.turnerconstruction.com\">Turner Construction</a>\r\n</td></tr>\r\n\r\n<tr><td class=\"name\">Pat Olson 	</td>\r\n<td>Standard Supply Company</td>\r\n</tr>\r\n<tr><td class=\"name\">Deacon John Ries 	</td>\r\n<td>St. Mary\'s Cathedral</td>\r\n</tr>\r\n\r\n<tr><td class=\"name\">Joshua Siler</td>\r\n<td><a href=\"http://www.hiringthing.com\">HiringThing, Inc.</a>\r\n</td></tr>\r\n<tr><td class=\"name\">Whitney True 	</td>\r\n<td>Lane PR</td>\r\n</tr>\r\n\r\n<tr><td class=\"name\">Sarah Williams</td>\r\n<td><a href=\"http://www.hollandresidential.com\">Holland Residential</a>\r\n</td></tr>\r\n<tr><td class=\"name\">Brandon Zabrocki 	</td>\r\n<td><a href=\"http://www.usbank.com\">US Bank</a>\r\n</td></tr>\r\n\r\n</tbody>\r\n</table>\r\n',0,'2011-12-24 20:58:11','2011-12-24 21:18:58'),(8,5,'Body','\r\n <p>\r\n We rely on social service agencies, town offices, service organizations, churches, community groups, and individuals\r\n to help us identify homeowners in Portland in need of our assistance. <strong>Do you know an elderly person, somebody with a disability,\r\n or a working family who could use our help?</strong>\r\n Please review the information on this site and contact us with a completed Home Referral Form.\r\n </p>\r\n<p>\r\n<strong>All repairs are free for homeowners. </strong>Labor and many supplies are typically donated. Homeowners and family members are asked to welcome the volunteers into their homes and work alongside them to the extent possible. Our work is done with families and neighborhoods, not for them. A homeowner brochure is provided to clarify our process and partnership.\r\n</p>\r\n<img src=\"/images/photos/2.jpg\" />\r\n <p>\r\nEligibility requirements include:\r\n</p>\r\n<ul>\r\n  <li>Applicants must own and live in the property where repair work will be done.\r\n  </li>\r\n<li>Assist low income individuals whom are also elderly or disabled or with children\r\n  </li>\r\n<li>Be unable both financially and physically to effect repairs themselves\r\n  </li>\r\n<li>Applicants must be able to produce their mortgage payment book, deed, or other documents showing ownership, if requested.\r\n  </li>\r\n<li>The property is not subject to any pending foreclosure actions or actions to enforce liens.\r\n  </li>\r\n<li>Persons residing in your home or visiting on the designated workday who are physically able will work alongside the volunteers.\r\n   </li>\r\n<li>Be located on a property in the city of Portland.\r\n</li>\r\n</ul>\r\n<p>\r\nIneligible homes include:\r\n</p>\r\n<ul>\r\n  <li>Rental properties\r\n  </li>\r\n<li>Household income above federal poverty guidelines\r\n</li>\r\n</ul>\r\n<p>\r\nHomeowners are carefully selected through an application process which includes income thresholds and a home inspection.\r\nMembers of our House Selection Committees visit applicant homes to confirm eligibility and assess work that needs to be done.\r\nWhile we complete major renovations — including upgrading electrical systems, and many other home\r\nimprovements — we narrow the scope of the work we undertake to what we believe a team of 10-50 skilled and unskilled\r\nvolunteers can accomplish in a day.\r\n</p>\r\n <p>\r\nThe number of homes we work on is tied directly to the amount of money we can raise during the year.\r\nThe House Selection Committee selects the qualifying homes for each year. On average, we renovate more than 50 homes a year\r\nfrom a list of about 150 homeowners. House Captains, generally skilled workers from sponsor groups select homes they\r\nwill champion and set up a detailed plan of work to be done at the home and is the primary contact for the homeowner\r\nthrough completion of the work.\r\n </p>\r\n <p>\r\nThere are no promises that the work planned will actually be done. Weather, volunteer availability and other factors may affect the actual work completed. The House Captain will decide what work can and cannot be done on the day of work. If your home is chosen for the rehabilitation work, there will be NO charge for our service.\r\n</p>\r\n <p>\r\n  <a href=\"/forms/2011/HomeownerReferralForm.docx\" style=\"font-size:1.4em;\">Click Here to Download an Application</a>\r\n </p>\r\n <h2>Contact Information</h2>\r\n<strong>Rebuilding Together * Portland</strong>\r\n<br />\r\n5000 N. Willamette Blvd. Portland, OR 97203-5798<br />\r\nPhone: 503-943-7515<br />\r\nFax: 503-943-7322<br />\r\n<a href=\"mailto:MikeMalone@rebuildingtogetherportland.org\">MikeMalone@rebuildingtogetherportland.org</a>\r\n<br />\r\n\r\n',0,'2011-12-24 20:59:29','2011-12-24 21:22:35'),(9,6,'Body',' \r\n <p>House Captains are our project leaders, and help ensure that each and every project is a success on rebuilding day.\r\n If you are interested in becoming a House Captain, please contact <a href=\"mailto:MikeMalone@RebuildingTogetherPortland.org\">Mike Malone at MikeMalone@RebuildingTogetherPortland.org</a>\r\n</p>\r\n\r\n <p>If you\'ve already signed up, <strong>thank you!</strong> The House Captain\'s role is a crucial element in making our program a success.  It is your skills, hard work and dedication that get our repair and rehabilitation work completed effectively and efficiently.  This role will be challenging and at the same time very rewarding.\r\n </p>\r\n<p>\r\nFor more information, start here: <a href=\"/files/RT2011hcltter.doc\">Letter to House Captains</a> (with 2011 schedule)\r\n</p>\r\n<h2>Resources for House Captains</h2>\r\n<ul>\r\n<li style=\"list-style-image: url(/images/icons/new.png);margin-bottom: 20px;\"><em>Updated for 2011</em>\r\n</li>\r\n\r\n\r\n<li style=\"list-style-image: url(/images/icons/page_white_acrobat.png);\"><a href=\"/files/2011/2011_campus_map.pdf\">\r\n	\r\n		Campus\r\n\r\n		Map\r\n</a>\r\n</li>\r\n\r\n\r\n<li style=\"list-style-image: url(/images/icons/page_word.png);\"><a href=\"/files/2011/2011_guidelines_for_house_liaisons.doc\">\r\n	\r\n		Guidelines\r\n\r\n		For\r\n\r\n		House\r\n\r\n		Liaisons\r\n</a>\r\n</li>\r\n\r\n\r\n<li style=\"list-style-image: url(/images/icons/page_word.png);\"><a href=\"/files/2011/2011_hc_handbook_planning_ahead.doc.doc\">\r\n	\r\n		Hc\r\n\r\n		Handbook\r\n\r\n		Planning\r\n\r\n		Ahead\r\n</a>\r\n</li>\r\n\r\n\r\n<li style=\"list-style-image: url(/images/icons/page_word.png);\"><a href=\"/files/2011/2011_hc_handbook_the_work_day.doc.doc\">\r\n	\r\n		Hc\r\n\r\n		Handbook\r\n\r\n		The\r\n\r\n		Work\r\n\r\n		Day\r\n</a>\r\n</li>\r\n\r\n\r\n<li style=\"list-style-image: url(/images/icons/page_word.png);\"><a href=\"/files/2011/2011_hc_orientation_agenda.doc\">\r\n	\r\n		Hc\r\n\r\n		Orientation\r\n\r\n		Agenda\r\n</a>\r\n</li>\r\n\r\n\r\n<li style=\"list-style-image: url(/images/icons/page_word.png);\"><a href=\"/files/2011/2011_hc_role_&amp;_responsibilities.doc\">\r\n	\r\n		Hc\r\n\r\n		Role\r\n\r\n		&amp;\r\n\r\n		Responsibilities\r\n</a>\r\n</li>\r\n\r\n\r\n<li style=\"list-style-image: url(/images/icons/page_word.png);\"><a href=\"/files/2011/2011_hc_volunteer_list_work_sheet.doc\">\r\n	\r\n		Hc\r\n\r\n		Volunteer\r\n\r\n		List\r\n\r\n		Work\r\n\r\n		Sheet\r\n</a>\r\n</li>\r\n\r\n\r\n<li style=\"list-style-image: url(/images/icons/page_word.png);\"><a href=\"/files/2011/2011_homeowner_agreement.doc\">\r\n	\r\n		Homeowner\r\n\r\n		Agreement\r\n</a>\r\n</li>\r\n\r\n\r\n<li style=\"list-style-image: url(/images/icons/page_word.png);\"><a href=\"/files/2011/2011_homeowner_interview-house_inspection_sign_up.doc\">\r\n	\r\n		Homeowner\r\n\r\n		Interview-house\r\n\r\n		Inspection\r\n\r\n		Sign\r\n\r\n		Up\r\n</a>\r\n</li>\r\n\r\n\r\n<li style=\"list-style-image: url(/images/icons/page_word.png);\"><a href=\"/files/2011/2011_house_captain_evaluation.doc\">\r\n	\r\n		House\r\n\r\n		Captain\r\n\r\n		Evaluation\r\n</a>\r\n</li>\r\n\r\n\r\n<li style=\"list-style-image: url(/images/icons/page_word.png);\"><a href=\"/files/2011/2011_house_captains_reminder_lttr.doc\">\r\n	\r\n		House\r\n\r\n		Captains\r\n\r\n		Reminder\r\n\r\n		Lttr\r\n</a>\r\n</li>\r\n\r\n\r\n<li style=\"list-style-image: url(/images/icons/page_word.png);\"><a href=\"/files/2011/2011_house_caption_flow_chart_for_recruiting_volunteers.doc\">\r\n	\r\n		House\r\n\r\n		Caption\r\n\r\n		Flow\r\n\r\n		Chart\r\n\r\n		For\r\n\r\n		Recruiting\r\n\r\n		Volunteers\r\n</a>\r\n</li>\r\n\r\n\r\n<li style=\"list-style-image: url(/images/icons/page_word.png);\"><a href=\"/files/2011/2011_lead-safe_remodeling_procedures.doc\">\r\n	\r\n		Lead-safe\r\n\r\n		Remodeling\r\n\r\n		Procedures\r\n</a>\r\n</li>\r\n\r\n\r\n<li style=\"list-style-image: url(/images/icons/page_white_acrobat.png);\"><a href=\"/files/2011/2011_lowes_order_form.pdf\">\r\n	\r\n		Lowes\r\n\r\n		Order\r\n\r\n		Form\r\n</a>\r\n</li>\r\n\r\n\r\n<li style=\"list-style-image: url(/images/icons/page_excel.png);\"><a href=\"/files/2011/2011_material_help.xls\">\r\n	\r\n		Material\r\n\r\n		Help\r\n</a>\r\n</li>\r\n\r\n\r\n<li style=\"list-style-image: url(/images/icons/page_word.png);\"><a href=\"/files/2011/2011_med_treatment_authorization_for_minor.doc\">\r\n	\r\n		Med\r\n\r\n		Treatment\r\n\r\n		Authorization\r\n\r\n		For\r\n\r\n		Minor\r\n</a>\r\n</li>\r\n\r\n\r\n<li style=\"list-style-image: url(/images/icons/page_word.png);\"><a href=\"/files/2011/2011_safety_tool_box_talk_guidelines.doc\">\r\n	\r\n		Safety\r\n\r\n		Tool\r\n\r\n		Box\r\n\r\n		Talk\r\n\r\n		Guidelines\r\n</a>\r\n</li>\r\n\r\n\r\n<li style=\"list-style-image: url(/images/icons/page_word.png);\"><a href=\"/files/2011/2011_scope_of_work.doc\">\r\n	\r\n		Scope\r\n\r\n		Of\r\n\r\n		Work\r\n</a>\r\n</li>\r\n\r\n\r\n<li style=\"list-style-image: url(/images/icons/page_word.png);\"><a href=\"/files/2011/2011_updated_volunteer_agreement_and_release.doc\">\r\n	\r\n		Updated\r\n\r\n		Volunteer\r\n\r\n		Agreement\r\n\r\n		And\r\n\r\n		Release\r\n</a>\r\n</li>\r\n\r\n\r\n<li style=\"list-style-image: url(/images/icons/page_word.png);\"><a href=\"/files/2011/2011_volunteer_estimate_form.doc\">\r\n	\r\n		Volunteer\r\n\r\n		Estimate\r\n\r\n		Form\r\n</a>\r\n</li>\r\n\r\n\r\n<li style=\"list-style-image: url(/images/icons/page_word.png);\"><a href=\"/files/2011/2011_volunteer_opportunities_form.doc\">\r\n	\r\n		Volunteer\r\n\r\n		Opportunities\r\n\r\n		Form\r\n</a>\r\n</li>\r\n\r\n\r\n<li style=\"list-style-image: url(/images/icons/page_word.png);\"><a href=\"/files/2011/lowes_material_procedures_2011.doc\">\r\n	\r\n		Lowes\r\n\r\n		Material\r\n\r\n		Procedures\r\n</a>\r\n</li>\r\n\r\n\r\n<li style=\"list-style-image: url(/images/icons/page_word.png);\"><a href=\"/files/2011/xmas_2011_hc_lttr.doc\">\r\n	\r\n		Xmas\r\n\r\n		Hc\r\n\r\n		Lttr\r\n</a>\r\n</li>\r\n\r\n</ul>\r\n\r\n <h2>Contact Information</h2>\r\n<strong>Dave Lyons, Committee Chairman</strong>\r\n<br />\r\nDays - 503-248-2030 and evenings - 503-287-9915<br />\r\nPlease confirm your attendance: <a href=\"dave@jdldev.com\">Dave Lyons - dave@jdldev.com</a> or <a href=\"mailto:MikeMalone@RebuildingTogetherPortland.org\">Mike Malone - MikeMalone@RebuildingTogetherPortland.org</a>\r\n<br /><br />\r\n<strong>Rebuilding Together * Portland</strong>\r\n<br />\r\n5000 N. Willamette Blvd. Portland, OR 97203-5798<br />\r\nPhone: 503-943-7515<br />\r\nFax: 503-943-7322<br />\r\n<a href=\"mailto:MikeMalone@rebuildingtogetherportland.org\">MikeMalone@rebuildingtogetherportland.org</a>\r\n<br />\r\n\r\n\r\n		\r\n',0,'2011-12-24 20:59:55','2011-12-24 21:21:15'),(10,7,'Body','\r\n<p>\r\n<strong>Free facility repairs available for Non-Profits.</strong> It\'s Rebuilding Together Portland to the rescue!\r\n</p>\r\n<p>\r\nSince 1990 Rebuilding Together Portland has been realizing ambitious annual goals to repair and rehabilitate both homes and non-profit community facilities. While more than 50 homes are worked on each year, Rebuilding Together Portland also helps five or six non-profits each year with free facility repairs. Rebuilding Together Portland matches coordinates projects year-round, but most of the work is done on the last Saturday in April each year by more than a thousand volunteers on that one day.\r\n</p>\r\n<p>\r\nRebuilding Together is a non-profit organization supported entirely by contributions of time, labor, materials, and money. Our core competencies include identifying worthy homeowners and non-profits in need and matching them with volunteers, supplies and materials. Rebuilding Together Portland coordinates skilled and unskilled volunteers and materials needed to complete the work in a day or two. We are always looking for good projects at non-profit properties where volunteers will enjoy and appreciate their contribution.\r\n</p>\r\n<p>\r\nTo be eligible for consideration, the applicant\'s property must:\r\n</p>\r\n<ul>\r\n    <li>Be the owner and occupant of the property\r\n    </li>\r\n<li>Assist low income individuals whom are also elderly or disabled or with children\r\n    </li>\r\n<li>Be unable both financially and physically to effect repairs themselves\r\n    </li>\r\n<li>Be located on a property in the city of Portland.\r\n</li>\r\n</ul>\r\n<p>\r\nSafety and security are the first priorities of Rebuilding Together. Our skilled and unskilled volunteers do all\r\ntypes of work including painting, plumbing, electrical, carpentry, weatherization, yard cleaning,\r\ndebris removal, and much more!\r\n</p>\r\n<p>\r\nWhen a project is accepted, a scope of work is defined in advance, but the non-profit organization and homeowners\r\nneed to understand these are volunteers and that time and weather may prevent them from\r\naccomplishing everything planned to be completed.\r\n</p>\r\n<p>\r\nTo become eligible for assistance, fill out our Non-profit Referral Form.\r\n</p>\r\n <p>\r\n  <a href=\"/forms/2012/Non-ProfitReferralForm12.doc\" style=\"font-size:1.4em;\">Click Here to Download an Application</a>\r\n </p>\r\n <h2>Contact Information</h2>\r\n<strong>Rebuilding Together * Portland</strong>\r\n<br />\r\n5000 N. Willamette Blvd. Portland, OR 97203-5798<br />\r\nPhone: 503-943-7515<br />\r\nFax: 503-943-7322<br />\r\n<a href=\"mailto:MikeMalone@rebuildingtogetherportland.org\">MikeMalone@rebuildingtogetherportland.org</a>\r\n<br />\r\n\r\n',0,'2011-12-24 21:00:43','2011-12-24 21:22:58'),(11,8,'Body','The elements of the \r\n									national logo consist of the artwork (\"the \r\n									symbol\") and the words Rebuilding Together. \r\n									It is a unique mark and may not be altered. \r\n									The logo must not be redrawn and cannot \r\n									include any additional graphic \r\n									embellishments. The position and size \r\n									relationship of the elements should not be \r\n									changed. It should be reproduced from the \r\n									artwork provided by the national \r\n									organization or from a digital version, \r\n									available on the CD accompanying this manual \r\n									or downloadable from the members-only \r\n									section of www.rebuildingtogether.org in a \r\n									number of formats and versions. The national \r\n									office has trademark protection for the \r\n									Rebuilding Together logo. Always use the ® \r\n									that appears at the base of the \"r\" in \r\n									\"Together.\" Do not use the logo as a part of \r\n									another corporate name.<br />\r\n									By downloading any logos from this site, you \r\n									are agreeing to adhere to these guidelines.\r\n\r\n<h2>Downloads</h2>\r\n<style>\r\n  img\r\n  {\r\n    border: none;\r\n  }\r\n</style>\r\n<table style=\"width: 100%\">\r\n									<tbody><tr>\r\n										<td class=\"style20\">\r\n										<span class=\"style19\">&#160;<a href=\"/logos/RT_2Clogo_horiz.jpg\" class=\"style14\"><img src=\"/images/RT_2Clogo_horiz_small.jpg\" width=\"344\" height=\"100\" class=\"style17\" /></a>\r\n<br />\r\n										<a href=\"/logos/RT_2Clogo_horiz.eps\">\r\n										RT_2Clogo_horiz.eps</a>\r\n<br />\r\n										<a href=\"/logos/RT_2Clogo_horiz.jpg\">\r\n										RT_2Clogo_horiz.jpg</a>\r\n<br />\r\n										</span>\r\n</td>\r\n										<td class=\"style23\">&#160;<a href=\"/logos/RT_2Clogo_stacked.jpg\"><span class=\"style22\"><img src=\"/images/RT_2Clogo_stacked_small.jpg\" width=\"204\" height=\"100\" class=\"style21\" /></span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n										<a href=\"/logos/RT_2Clogo_stacked.jpg\">\r\n										<span class=\"style22\">\r\n										RT_2Clogo_stacked.jpg</span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n										<a href=\"/logos/RT_2Clogo_stacked.eps\">\r\n										<span class=\"style22\">\r\n										RT_2Clogo_stacked.eps</span>\r\n</a>\r\n</td>\r\n									</tr>\r\n									<tr class=\"style19\">\r\n										<td class=\"style23\">\r\n										<span class=\"style22\">&#160;</span>\r\n<a href=\"/logos/RT_Blacklogo_horiz.jpg\"><span class=\"style22\"><img src=\"/images/RT_Blacklogo_horiz_small.jpg\" width=\"344\" height=\"100\" class=\"style21\" /></span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n										<a href=\"/logos/RT_Blacklogo_horiz.jpg\">\r\n										<span class=\"style22\">\r\n										RT_Blacklogo_horiz.jpg</span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n										<a href=\"/logos/RT_Blacklogo_horiz.eps\">\r\n										<span class=\"style22\">\r\n										RT_Blacklogo_horiz.eps</span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n</td>\r\n										<td class=\"style23\">&#160;<a href=\"/logos/RT_Blacklogo_stacked.jpg\"><span class=\"style22\"><img src=\"/images/RT_Blacklogo_stacked_small.jpg\" width=\"204\" height=\"100\" class=\"style21\" /></span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n										<a href=\"/logos/RT_Blacklogo_stacked.jpg\">\r\n										<span class=\"style22\">\r\n										RT_Blacklogo_stacked.jpg</span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n										<a href=\"/logos/RT_Blacklogo_stacked.eps\">\r\n										<span class=\"style22\">\r\n										RT_Blacklogo_stacked.eps</span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n</td>\r\n									</tr>\r\n									<tr class=\"style19\">\r\n										<td class=\"style23\">\r\n										<span class=\"style22\">&#160;</span>\r\n<a href=\"/logos/RT_GSlogo_horiz.jpg\"><span class=\"style22\"><img src=\"/images/RT_GSlogo_horiz_small.jpg\" width=\"344\" height=\"100\" class=\"style21\" /></span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n										<a href=\"/logos/RT_GSlogo_horiz.jpg\">\r\n										<span class=\"style22\">\r\n										RT_GSlogo_horiz.jpg</span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n										<a href=\"/logos/RT_GSlogo_horiz.eps\">\r\n										<span class=\"style22\">\r\n										RT_GSlogo_horiz.eps</span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n</td>\r\n										<td class=\"style23\">&#160;<a href=\"/logos/RT_GSlogo_stacked.jpg\"><span class=\"style22\"><img src=\"/images/RT_GSlogo_stacked_small.jpg\" width=\"204\" height=\"100\" class=\"style21\" /></span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n										<a href=\"/logos/RT_GSlogo_stacked.jpg\">\r\n										<span class=\"style22\">\r\n										RT_GSlogo_stacked.jpg</span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n										<a href=\"/logos/RT_GSlogo_stacked.eps\">\r\n										<span class=\"style22\">\r\n										RT_GSlogo_stacked.eps</span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n</td>\r\n									</tr>\r\n									<tr class=\"style19\">\r\n										<td class=\"style23\">\r\n										<span class=\"style22\">&#160;</span>\r\n<a href=\"/logos/RT_PMS368logo_horiz.jpg\"><span class=\"style22\"><img src=\"/images/RT_PMS368logo_horiz_small.jpg\" width=\"344\" height=\"100\" class=\"style21\" /></span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n										<a href=\"/logos/RT_PMS368logo_horiz.jpg\">\r\n										<span class=\"style22\">\r\n										RT_PMS368logo_horiz.jpg</span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n										<a href=\"/logos/RT_PMS368logo_horiz.eps\">\r\n										<span class=\"style22\">\r\n										RT_PMS368logo_horiz.eps</span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n</td>\r\n										<td class=\"style23\">&#160;<a href=\"/logos/RT_PMS368logo_stacked.jpg\"><span class=\"style22\"><img src=\"/images/RT_PMS368logo_stacked_small.jpg\" width=\"204\" height=\"100\" class=\"style21\" /></span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n										<a href=\"/logos/RT_PMS368logo_stacked.jpg\">\r\n										<span class=\"style22\">\r\n										RT_PMS368logo_stacked.jpg</span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n										<a href=\"/logos/RT_PMS368logo_stacked.eps\">\r\n										<span class=\"style22\">\r\n										RT_PMS368logo_stacked.eps</span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n</td>\r\n									</tr>\r\n									<tr class=\"style19\">\r\n										<td class=\"style23\">\r\n										<span class=\"style22\">&#160;</span>\r\n<a href=\"/logos/RT_KOlogo_horiz.jpg\"><span class=\"style22\"><img src=\"/images/RT_KOlogo_horiz_small.jpg\" width=\"291\" height=\"100\" class=\"style21\" /></span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n										<a href=\"/logos/RT_KOlogo_horiz.jpg\">\r\n										<span class=\"style22\">\r\n										RT_KOlogo_horiz.jpg</span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n										<a href=\"/logos/RT_KOlogo_horiz.eps\">\r\n										<span class=\"style22\">\r\n										RT_KOlogo_horiz.eps</span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n</td>\r\n										<td class=\"style23\">&#160;<a href=\"/logos/RT_KOlogo_stacked.jpg\"><span class=\"style22\"><img src=\"/images/RT_KOlogo_stacked_small.jpg\" width=\"192\" height=\"100\" class=\"style21\" /></span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n										<a href=\"/logos/RT_KOlogo_stacked.jpg\">\r\n										<span class=\"style22\">\r\n										RT_KOlogo_stacked.jpg</span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n										<a href=\"/logos/RT_KOlogo_stacked.eps\">\r\n										<span class=\"style22\">\r\n										RT_KOlogo_stacked.eps</span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n</td>\r\n									</tr>\r\n									<tr class=\"style19\">\r\n										<td class=\"style23\">\r\n										<span class=\"style22\">&#160;</span>\r\n<a href=\"/logos/RT_KOlogo_horizWHT.jpg\"><span class=\"style22\"><img src=\"/images/RT_KOlogo_horizWHT_small.jpg\" width=\"282\" height=\"100\" class=\"style21\" /></span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n										<a href=\"/logos/RT_KOlogo_horizWHT.jpg\">\r\n										<span class=\"style22\">\r\n										RT_KOlogo_horizWHT.jpg</span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n										<a href=\"/logos/RT_KOlogo_horizWHT.eps\">\r\n										<span class=\"style22\">\r\n										RT_KOlogo_horizWHT.eps</span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n</td>\r\n										<td class=\"style23\">&#160;<a href=\"/logos/RT_KOlogo_stackedWHT.jpg\"><span class=\"style22\"><img src=\"/images/RT_KOlogo_stackedWHT_small.jpg\" width=\"184\" height=\"100\" class=\"style21\" /></span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n										<a href=\"/logos/RT_KOlogo_stackedWHT.jpg\">\r\n										<span class=\"style22\">\r\n										RT_KOlogo_stackedWHT.jpg</span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n										<a href=\"/logos/RT_KOlogo_stackedWHT.eps\">\r\n										<span class=\"style22\">\r\n										RT_KOlogo_stackedWHT.eps</span>\r\n</a>\r\n<span class=\"style22\"><br />\r\n										</span>\r\n</td>\r\n									</tr>\r\n								</tbody>\r\n</table>',0,'2011-12-24 21:02:35','2011-12-24 21:03:14'),(12,9,'Body','<p>\r\n	<strong>You can make a difference.</strong> Experience the great feeling that comes with helping out your community. Our volunteers come to us with all different levels of skills, and every helping hand makes a difference.\r\n	Whether you\'re a skilled tradesman or simply looking to help out any way you can, please fill out the form below to get started. Also, we\'ll need these forms completed before the work day:\r\n<br /><br />\r\n\r\n<a href=\"/files/2011/2011_med_treatment_authorization_for_minor.doc\">Medical Treatment Authorization (for minors)</a>\r\n<br />\r\n<a href=\"/files/2011/2011_updated_volunteer_agreement_and_release.doc\">Volunteer\'s Agreement</a>\r\n</p>\r\n',0,'2011-12-24 21:27:22','2011-12-24 21:33:50'),(13,9,'Side Body','<p><strong>Rebuilding Together * Portland</strong>\r\n<br />\r\n5000 N. Willamette Blvd. Portland, OR 97203-5798<br />\r\nPhone: 503-943-7515<br />\r\nFax: 503-943-7322<br />\r\n<a href=\"mailto:MikeMalone@rebuildingtogetherportland.org\">MikeMalone@rebuildingtogetherportland.org</a>\r\n<br />\r\n</p>\r\n',1,'2011-12-24 21:27:22','2011-12-24 21:33:50'),(14,10,'Body','<p>We\'ve received your inquiry and will get back to you with a response shortly.</p><p><a href=\'/\'>Return to the home page</a></p>',0,'2011-12-24 21:27:22','2011-12-24 21:27:22'),(15,11,'Body','<p>We respect your privacy. We do not market, rent or sell our email list to any outside parties.</p><p>We need your e-mail address so that we can ensure that the people using our forms are bona fide. It also allows us to send you e-mail newsletters and other communications, if you opt-in. Your postal address is required in order to send you information and pricing, if you request it.</p><p>Please call us at 123 456 7890 if you have any questions or concerns.</p>',0,'2011-12-24 21:27:22','2011-12-24 21:27:22');
/*!40000 ALTER TABLE `page_parts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `page_translations`
--

DROP TABLE IF EXISTS `page_translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `page_translations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_id` int(11) DEFAULT NULL,
  `locale` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `custom_title` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_page_translations_on_page_id` (`page_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `page_translations`
--

LOCK TABLES `page_translations` WRITE;
/*!40000 ALTER TABLE `page_translations` DISABLE KEYS */;
INSERT INTO `page_translations` VALUES (1,1,'en','Rebuilding Together Portland','','2011-12-24 20:46:03','2011-12-24 21:04:29'),(2,2,'en','Page not found',NULL,'2011-12-24 20:46:03','2011-12-24 20:46:03'),(3,3,'en','About Us','','2011-12-24 20:46:03','2011-12-24 20:53:55'),(4,4,'en','Board of Directors','','2011-12-24 20:58:11','2011-12-24 20:58:11'),(5,5,'en','Homeowners','','2011-12-24 20:59:29','2011-12-24 20:59:29'),(6,6,'en','House Captains','','2011-12-24 20:59:55','2011-12-24 20:59:55'),(7,7,'en','Non-Profits','','2011-12-24 21:00:43','2011-12-24 21:00:43'),(8,8,'en','Official Logos','','2011-12-24 21:02:35','2011-12-24 21:03:14'),(9,9,'en','Volunteer','','2011-12-24 21:27:22','2011-12-24 21:31:00'),(10,10,'en','Thank You',NULL,'2011-12-24 21:27:22','2011-12-24 21:27:22'),(11,11,'en','Privacy Policy',NULL,'2011-12-24 21:27:22','2011-12-24 21:27:22');
/*!40000 ALTER TABLE `page_translations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `path` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `show_in_menu` tinyint(1) DEFAULT '1',
  `link_url` varchar(255) DEFAULT NULL,
  `menu_match` varchar(255) DEFAULT NULL,
  `deletable` tinyint(1) DEFAULT '1',
  `custom_title_type` varchar(255) DEFAULT 'none',
  `draft` tinyint(1) DEFAULT '0',
  `skip_to_first_child` tinyint(1) DEFAULT '0',
  `lft` int(11) DEFAULT NULL,
  `rgt` int(11) DEFAULT NULL,
  `depth` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_pages_on_depth` (`depth`),
  KEY `index_pages_on_id` (`id`),
  KEY `index_pages_on_lft` (`lft`),
  KEY `index_pages_on_parent_id` (`parent_id`),
  KEY `index_pages_on_rgt` (`rgt`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES (1,NULL,0,NULL,'2011-12-24 20:46:03','2011-12-24 21:42:42',1,'/',NULL,0,'none',0,0,1,4,NULL),(2,1,0,NULL,'2011-12-24 20:46:03','2011-12-24 20:46:03',0,NULL,'^/404$',0,'none',0,0,2,3,NULL),(3,NULL,1,NULL,'2011-12-24 20:46:03','2011-12-24 21:19:14',1,'',NULL,1,'none',0,0,5,6,NULL),(4,NULL,2,NULL,'2011-12-24 20:58:11','2011-12-24 21:18:58',1,'',NULL,1,'none',0,0,7,8,NULL),(5,NULL,3,NULL,'2011-12-24 20:59:29','2011-12-24 21:22:35',1,'',NULL,1,'none',0,0,9,10,NULL),(6,NULL,4,NULL,'2011-12-24 20:59:55','2011-12-24 21:21:15',1,'',NULL,1,'none',0,0,11,12,NULL),(7,NULL,5,NULL,'2011-12-24 21:00:43','2011-12-24 21:22:58',1,'',NULL,1,'none',0,0,13,14,NULL),(8,NULL,6,NULL,'2011-12-24 21:02:35','2011-12-24 21:03:14',1,'',NULL,1,'none',0,0,15,16,NULL),(9,NULL,7,NULL,'2011-12-24 21:27:22','2011-12-24 21:33:50',1,'/contact','^/(inquiries|contact).*$',0,'none',0,0,17,22,NULL),(10,9,0,NULL,'2011-12-24 21:27:22','2011-12-24 21:27:22',0,'/contact/thank_you','^/(inquiries|contact)/thank_you$',0,'none',0,0,18,19,NULL),(11,9,1,NULL,'2011-12-24 21:27:22','2011-12-24 21:27:22',0,NULL,NULL,1,'none',0,0,20,21,NULL);
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refinery_settings`
--

DROP TABLE IF EXISTS `refinery_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `refinery_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `value` text,
  `destroyable` tinyint(1) DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `scoping` varchar(255) DEFAULT NULL,
  `restricted` tinyint(1) DEFAULT '0',
  `callback_proc_as_string` varchar(255) DEFAULT NULL,
  `form_value_type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_refinery_settings_on_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refinery_settings`
--

LOCK TABLES `refinery_settings` WRITE;
/*!40000 ALTER TABLE `refinery_settings` DISABLE KEYS */;
INSERT INTO `refinery_settings` VALUES (1,'use_marketable_urls','--- \"true\"\n',1,'2011-12-24 20:46:03','2011-12-24 20:46:03','pages',0,NULL,'text_area'),(2,'dragonfly_secret','--- 51c976986283de43e4ea5c95f7e105f24f973bc96f53cc18\n',1,'2011-12-24 20:46:13','2011-12-24 20:46:13',NULL,0,NULL,'text_area'),(3,'approximate_ascii','--- \"false\"\n',1,'2011-12-24 20:46:14','2011-12-24 20:46:14','pages',0,NULL,'text_area'),(4,'strip_non_ascii','--- \"false\"\n',1,'2011-12-24 20:46:14','2011-12-24 20:46:14','pages',0,NULL,'text_area'),(5,'i18n_translation_default_frontend_locale','--- :en\n',1,'2011-12-24 20:52:20','2011-12-24 20:52:20','refinery',0,NULL,'text_area'),(6,'i18n_translation_enabled','--- \"true\"\n',1,'2011-12-24 20:52:27','2011-12-24 20:52:27','refinery',0,NULL,'text_area'),(7,'i18n_translation_locales','--- \n:it: Italiano\n:da: Dansk\n:nl: Nederlands\n:de: Deutsch\n:lv: Latviski\n:en: English\n:rs: Srpski\n:nb: \"Norsk Bokm\\xC3\\xA5l\"\n:ru: !binary |\n  0KDRg9GB0YHQutC40Lk=\n\n:sk: \"Slovensk\\xC3\\xBD\"\n:sl: Slovenian\n:cs: !binary |\n  xIxlc2t5\n\n:\"zh-CN\": Simplified Chinese\n:sv: Svenska\n:fr: \"Fran\\xC3\\xA7ais\"\n:jp: !binary |\n  5pel5pys6Kqe\n\n:es: \"Espa\\xC3\\xB1ol\"\n:el: !binary |\n  zpXOu867zrfOvc65zrrOrA==\n\n:\"zh-TW\": Traditional Chinese\n:pl: Polski\n:\"pt-BR\": \"Portugu\\xC3\\xAAs\"\n',1,'2011-12-24 20:52:27','2011-12-24 20:52:27','refinery',0,NULL,'text_area'),(8,'i18n_translation_default_locale','--- :en\n',1,'2011-12-24 20:52:27','2011-12-24 20:52:27','refinery',0,NULL,'text_area'),(9,'i18n_translation_current_locale','--- :en\n',1,'2011-12-24 20:52:27','2011-12-24 20:52:27','refinery',0,NULL,'text_area'),(10,'i18n_translation_frontend_locales','--- \n- :en\n',1,'2011-12-24 20:52:27','2011-12-24 20:52:27','refinery',0,NULL,'text_area'),(11,'site_name','--- Rebuilding Together Portland\n',1,'2011-12-24 20:52:28','2011-12-24 20:53:06',NULL,0,NULL,'text_area'),(12,'use_resource_caching','--- \"true\"\n',1,'2011-12-24 20:52:28','2011-12-24 20:52:28',NULL,0,NULL,'text_area'),(13,'use_google_ajax_libraries','--- \"false\"\n',1,'2011-12-24 20:52:28','2011-12-24 20:52:28',NULL,0,NULL,'text_area'),(14,'activity_show_limit','--- 7\n',1,'2011-12-24 20:52:47','2011-12-24 20:52:47',NULL,0,NULL,'text_area'),(15,'cache_pages_backend','--- \"false\"\n',1,'2011-12-24 20:53:10','2011-12-24 20:53:10',NULL,0,NULL,'text_area'),(16,'new_page_parts','--- \"false\"\n',1,'2011-12-24 20:53:18','2011-12-24 20:53:18',NULL,0,NULL,'text_area'),(17,'page_title','--- \n:page_title: \n  :wrap_if_not_chained: false\n  :class: \n  :tag: \n:ancestors: \n  :class: ancestors\n  :tag: span\n  :separator: \" | \"\n:chain_page_title: false\n',1,'2011-12-24 20:54:02','2011-12-24 20:54:02',NULL,0,NULL,'text_area'),(18,'default_page_parts','--- \n- Body\n',1,'2011-12-24 20:57:23','2011-12-24 20:58:25',NULL,0,NULL,'text_area'),(19,'show_contact_privacy_link','--- \"false\"\n',1,'2011-12-24 21:28:53','2011-12-24 21:28:53',NULL,0,NULL,'text_area'),(20,'image_views','--- \n- :grid\n- :list\n',1,'2011-12-24 21:33:57','2011-12-24 21:33:57',NULL,0,NULL,'text_area'),(21,'preferred_image_view','--- :grid\n',1,'2011-12-24 21:33:57','2011-12-24 21:33:57',NULL,0,NULL,'text_area');
/*!40000 ALTER TABLE `refinery_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resources`
--

DROP TABLE IF EXISTS `resources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resources` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file_mime_type` varchar(255) DEFAULT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `file_size` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `file_uid` varchar(255) DEFAULT NULL,
  `file_ext` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resources`
--

LOCK TABLES `resources` WRITE;
/*!40000 ALTER TABLE `resources` DISABLE KEYS */;
/*!40000 ALTER TABLE `resources` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Refinery'),(2,'Superuser');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles_users`
--

DROP TABLE IF EXISTS `roles_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles_users` (
  `user_id` int(11) DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL,
  KEY `index_roles_users_on_role_id_and_user_id` (`role_id`,`user_id`),
  KEY `index_roles_users_on_user_id_and_role_id` (`user_id`,`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles_users`
--

LOCK TABLES `roles_users` WRITE;
/*!40000 ALTER TABLE `roles_users` DISABLE KEYS */;
INSERT INTO `roles_users` VALUES (1,1),(1,2);
/*!40000 ALTER TABLE `roles_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schema_migrations`
--

DROP TABLE IF EXISTS `schema_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schema_migrations` (
  `version` varchar(255) NOT NULL,
  UNIQUE KEY `unique_schema_migrations` (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schema_migrations`
--

LOCK TABLES `schema_migrations` WRITE;
/*!40000 ALTER TABLE `schema_migrations` DISABLE KEYS */;
INSERT INTO `schema_migrations` VALUES ('20111224204442'),('20111224204443'),('20111224204444'),('20111224204445'),('20111224204446'),('20111224204447'),('20111224204448'),('20111224204449'),('20111224204450'),('20111224204451'),('20111224204452'),('20111224204453'),('20111224204454'),('20111224204455'),('20111224204456'),('20111224204457'),('20111224204458'),('20111224212546'),('20111224212547');
/*!40000 ALTER TABLE `schema_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seo_meta`
--

DROP TABLE IF EXISTS `seo_meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `seo_meta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `seo_meta_id` int(11) DEFAULT NULL,
  `seo_meta_type` varchar(255) DEFAULT NULL,
  `browser_title` varchar(255) DEFAULT NULL,
  `meta_keywords` varchar(255) DEFAULT NULL,
  `meta_description` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_seo_meta_on_id` (`id`),
  KEY `index_seo_meta_on_seo_meta_id_and_seo_meta_type` (`seo_meta_id`,`seo_meta_type`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seo_meta`
--

LOCK TABLES `seo_meta` WRITE;
/*!40000 ALTER TABLE `seo_meta` DISABLE KEYS */;
INSERT INTO `seo_meta` VALUES (1,1,'Page::Translation','','','','2011-12-24 20:46:03','2011-12-24 21:04:29'),(2,2,'Page::Translation',NULL,NULL,NULL,'2011-12-24 20:46:03','2011-12-24 20:46:03'),(3,3,'Page::Translation','','','','2011-12-24 20:46:03','2011-12-24 20:53:55'),(4,4,'Page::Translation','','','','2011-12-24 20:58:11','2011-12-24 20:58:11'),(5,5,'Page::Translation','','','','2011-12-24 20:59:29','2011-12-24 20:59:29'),(6,6,'Page::Translation','','','','2011-12-24 20:59:55','2011-12-24 20:59:55'),(7,7,'Page::Translation','','','','2011-12-24 21:00:43','2011-12-24 21:00:43'),(8,8,'Page::Translation','','','','2011-12-24 21:02:35','2011-12-24 21:02:35'),(9,9,'Page::Translation','','','','2011-12-24 21:27:22','2011-12-24 21:31:00'),(10,10,'Page::Translation',NULL,NULL,NULL,'2011-12-24 21:27:22','2011-12-24 21:27:22'),(11,11,'Page::Translation',NULL,NULL,NULL,'2011-12-24 21:27:22','2011-12-24 21:27:22');
/*!40000 ALTER TABLE `seo_meta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `slugs`
--

DROP TABLE IF EXISTS `slugs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `slugs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `sluggable_id` int(11) DEFAULT NULL,
  `sequence` int(11) NOT NULL DEFAULT '1',
  `sluggable_type` varchar(40) DEFAULT NULL,
  `scope` varchar(40) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `locale` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_slugs_on_n_s_s_and_s` (`name`,`sluggable_type`,`scope`,`sequence`),
  KEY `index_slugs_on_sluggable_id` (`sluggable_id`),
  KEY `index_slugs_on_locale` (`locale`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `slugs`
--

LOCK TABLES `slugs` WRITE;
/*!40000 ALTER TABLE `slugs` DISABLE KEYS */;
INSERT INTO `slugs` VALUES (1,'home',1,1,'Page',NULL,'2011-12-24 20:46:03','en'),(2,'page-not-found',2,1,'Page',NULL,'2011-12-24 20:46:03','en'),(3,'about',3,1,'Page',NULL,'2011-12-24 20:46:03','en'),(4,'rebuilding',1,1,'User',NULL,'2011-12-24 20:52:46','en'),(5,'about-us',3,1,'Page',NULL,'2011-12-24 20:53:55','en'),(6,'board-of-directors',4,1,'Page',NULL,'2011-12-24 20:58:11','en'),(7,'homeowners',5,1,'Page',NULL,'2011-12-24 20:59:29','en'),(8,'house-captains',6,1,'Page',NULL,'2011-12-24 20:59:55','en'),(9,'non-profits',7,1,'Page',NULL,'2011-12-24 21:00:43','en'),(10,'logos-page',8,1,'Page',NULL,'2011-12-24 21:02:35','en'),(11,'official-logos',8,1,'Page',NULL,'2011-12-24 21:03:14','en'),(12,'rebuilding-together-portland',1,1,'Page',NULL,'2011-12-24 21:04:29','en'),(13,'contact-page',9,1,'Page',NULL,'2011-12-24 21:27:22','en'),(14,'thank-you',10,1,'Page',NULL,'2011-12-24 21:27:22','en'),(15,'privacy-policy',11,1,'Page',NULL,'2011-12-24 21:27:22','en'),(16,'volunteer',9,1,'Page',NULL,'2011-12-24 21:31:00','en');
/*!40000 ALTER TABLE `slugs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_plugins`
--

DROP TABLE IF EXISTS `user_plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_unique_user_plugins` (`user_id`,`name`),
  KEY `index_user_plugins_on_title` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_plugins`
--

LOCK TABLES `user_plugins` WRITE;
/*!40000 ALTER TABLE `user_plugins` DISABLE KEYS */;
INSERT INTO `user_plugins` VALUES (7,1,'refinery_dashboard',0),(8,1,'refinery_files',1),(9,1,'refinery_images',2),(10,1,'refinery_pages',3),(11,1,'refinery_settings',4),(12,1,'refinery_users',5),(13,1,'refinerycms_base',6),(14,1,'refinery_core',7),(15,1,'refinery_dialogs',8),(16,1,'refinery_i18n',9),(17,1,'refinery_generators',10),(18,1,'refinery_inquiries',11);
/*!40000 ALTER TABLE `user_plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `encrypted_password` varchar(255) NOT NULL,
  `persistence_token` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `perishable_token` varchar(255) DEFAULT NULL,
  `current_sign_in_at` datetime DEFAULT NULL,
  `last_sign_in_at` datetime DEFAULT NULL,
  `current_sign_in_ip` varchar(255) DEFAULT NULL,
  `last_sign_in_ip` varchar(255) DEFAULT NULL,
  `sign_in_count` int(11) DEFAULT NULL,
  `remember_token` varchar(255) DEFAULT NULL,
  `reset_password_token` varchar(255) DEFAULT NULL,
  `remember_created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_users_on_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'rebuilding','joshua.siler@gmail.com','$2a$10$bfNsfOEIJpu0Gjtw4v2vIO9JryApxv9jXabRHWuq55P.f5H5mr5YK',NULL,'2011-12-24 20:52:46','2011-12-24 20:52:46',NULL,'2011-12-24 20:52:46','2011-12-24 20:52:46','127.0.0.1','127.0.0.1',1,NULL,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2011-12-24 15:24:45
